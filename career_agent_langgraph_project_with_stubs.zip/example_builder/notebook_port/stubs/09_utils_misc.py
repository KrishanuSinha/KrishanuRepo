"""
This is a logical placeholder that maps to the original notebook export.
Runtime source of truth remains: example_builder.notebook_port.exported_from_notebook

You can migrate code from the commented excerpt below into this module later,
but for now we re-export all symbols to keep behavior unchanged.
"""
from example_builder.notebook_port.exported_from_notebook import *  # noqa: F401,F403

# --- Suggested excerpts from the notebook for this module (commented) ---
# (Move/refactor when ready; do NOT execute here until refactor is complete.)
# ------------------------------------------------------------------------
# def pkg_ver(name):
# def mod_path(modname):
# def get_pg_pool(minconn=1, maxconn=4):
# def get_bedrock_runtime():
# def get_bedrock_agent_runtime():
# def get_s3(region: str):
# def embed_texts(texts: list[str]) -> list[list[float]]:
# def get_bedrock_runtime(*_args, **_kwargs):
# def get_bedrock_agent_runtime(*_args, **_kwargs):
# def normalize_bedrock_model_id(mid: str) -> str:
# def get_bedrock_runtime_chat():
# def get_bedrock_runtime_embed():
# def get_bedrock_agent_runtime_kb():
# def apply_manager_course_gate(snippets: list[dict], is_manager: bool) -> list[dict]:
# def _pg_conn(dsn: str):
# def _pg_select(conn, sql: str, params: dict):
# def _json_loads_maybe(x):
# def _pg_conn(dsn: str):
# def _pg_select(conn, sql: str, params: dict):
# def _infer_focus_from_profile(profile: dict) -> list[str]:
# def mentor_finder_robust(
# def mentor_find_by_skill(
# def get_s3():
# def _sidecar_key(uri: str) -> str:
# def read_course_sidecar(uri: str) -> dict:
# def _is_course_snippet(snippet: dict) -> bool:
# def split_snippets(snippets: list[dict]) -> tuple[list[dict], list[dict], list[dict]]:
# def pg_lookup_profile_by_email_join(
# def pg_semantic_search_langchain(
# def normalize_bedrock_model_id(mid: str) -> str:
# def now_ms() -> int:
# def record_timing(state: Dict[str, Any], label: str):
# def mask_email(email: str) -> str:
# def trim(s: str, n: int=800) -> str:
# def json_dumps(obj) -> str:
# def safe_json_loads(txt: str) -> Any:
# def sha1(s: str) -> str:
# class GraphState(TypedDict, total=False):
# def new_state(query: str, email: Optional[str]) -> GraphState:
# def _utc_ts():
# def add_audit(state: GraphState, event: str, **kv):
# def warn(state: GraphState, msg: str, **kv):
# def record_timing(state: GraphState, label: str):
# def is_career_related(q: str) -> bool:
# def classify_intents_llm(query: str, model_id: str) -> tuple[list[str], str]:
# def build_plan_from_intents(intents: list[str]) -> tuple[dict, list[str]]:
# def infer_focus_skills(query: str) -> list[str]:
# def load_config_from_pg(config_name: str="career_agent", table: str="ai.agent_config") -> Optional[dict]:
# def load_config_from_s3(uri: str) -> Optional[dict]:
# def load_config_local(path: str="agent_config.yaml") -> Optional[dict]:
# def autopick_models(cfg: dict) -> dict:
# def bedrock_chat_json(model_id: str, system: str, user: str,
# def fetch_employee_profile(email: str, budget_secs: float=0.25) -> Dict[str, Any]:
# def embed_text(text, model_id):
# def join_retrieval(snippets: List[Dict[str,Any]], k: int=5) -> Tuple[List[Dict[str,Any]], List[Dict[str,Any]]]:
#     for s in sorted(fused, key=lambda x: x.get("score",0.0), reverse=True):
# def read_course_sidecar(uri: str) -> Dict[str,Any]:
# def apply_manager_gating(snippets: List[Dict[str,Any]], is_manager: bool, enable_rule: bool=True) -> List[Dict[str,Any]]:
# def apply_privacy_and_language(state: GraphState) -> GraphState:
# def compose_user_message_with_mentors(
#     def _source_line(idx: int, s: dict) -> str:
# def _is_haiku(model_id: str) -> bool:
# def build_synthetic_preamble(state: GraphState) -> str:
#     def _runner():
#         def _print_stream(resp):
# def with_updates(fn):
#     def _wrapped(state: GraphState):
# def assert_no_audit_key(state: GraphState, who: str):
# def build_graph(with_checkpointer: bool=True):
#     def allow_or_block(state: GraphState) -> str:
#     def need_mentors(state: GraphState) -> str:
# def _graph_cfg(state):
# def run_demo(query: str, email: Optional[str]=None, stream_events: bool=True):
# def synthesize_answer_llm_stream(
# # ==== Cell 2 ====
# # # Upgrade pip tooling first
# # !python -m pip install --upgrade pip setuptools wheel

# # # Remove old/conflicting packages
# # !python -m pip uninstall -y langchain langchain-core langchain-community langgraph

# # # Install a compatible set (for Python 3.12)
# # !python -m pip install langchain==0.3.12
# # !python -m pip install langchain-core==0.3.25
# # !python -m pip install langchain-community==0.3.12
# # !python -m pip install langgraph==0.2.39

# # # Supporting dependencies
# # !python -m pip install "pydantic>=2.6" "typing-extensions>=4.9"



# # ==== Cell 3 ====

#     try:
#         return md.version(name)
#     except md.PackageNotFoundError:
#         return "(not installed)"

#     try:
#         m = importlib.import_module(modname)
#         return getattr(m, "__file__", "(no __file__)")
#     except Exception as e:
#         return f"(import error: {e})"

# print("Python:", sys.executable)
# print("langgraph version:", pkg_ver("langgraph"))
# print("langchain version:", pkg_ver("langchain"))
# print("langchain-core version:", pkg_ver("langchain-core"))
# print("langchain-community version:", pkg_ver("langchain-community"))

# print("\nModule paths (to confirm you’re in the right env):")
# print("langgraph path:", mod_path("langgraph"))
# print("langchain path:", mod_path("langchain"))
# print("langchain_core path:", mod_path("langchain_core"))


# # ==== Cell 4 ====
# # %%

# load_dotenv()




# # ==== Cell 6 ====

# # === FIXED CONFIG (your account) ===
# # === FIXED CONFIG (single region) ===

# # Backward-compat aliases (stop the NameError)



# # PG
# # PROD_SNIPPETS_TABLE = "internal_curated_informa_vectorstore"
# # DEV_PROFILE_TABLE   = "internal_private_employee_profiles_vectorstore"

# os.environ["LANGCHAIN_TRACING_V2"] = "false"
# # Optional: clear endpoint if it’s set
# os.environ.pop("LANGCHAIN_ENDPOINT", None)

# # Force preamble to use your primary chat model (works immediately)








#     global PG_POOL
#     if PG_POOL is None:
#     return PG_POOL

# # 2) Region-correct clients (all in us-west-2)





# # ==== Cell 7 ====
# # --- Embedding helper (plural) using your existing embed_text ---
#     # Bedrock Titan doesn’t batch in our wrapper; do simple map
#     return [embed_text(t, model_id=state["config"]["models"]["embedding"] if "state" in globals() else DEFAULT_FIXED_CONFIG["models"]["embedding"])
#             for t in texts]


# # ==== Cell 9 ====



# # Singletons
# __bedrock_runtime = None
# __bedrock_agent_runtime = None

#     global __bedrock_runtime
#     if __bedrock_runtime is None:
#     return __bedrock_runtime

#     global __bedrock_agent_runtime
#     if __bedrock_agent_runtime is None:
#     return __bedrock_agent_runtime



# # --- Regions you provided ---

# # --- Model ID normalization (strips accidental "us."/"eu." prefixes etc.) ---
#     if not mid:
#         return ""
#     m = mid.strip()
#     if m.startswith("arn:aws:bedrock"):  # inference profile ARN -> leave as-is
#         return m
#     low = m.lower()
#     if low.startswith(("us.", "eu.", "ap.")):
#         m = m.split(".", 1)[1]  # drop the prefix like "us."
#     return m

# # --- Clients by region ---
# _brt_chat = None
# _brt_embed = None
# _ba_runtime = None

#     global _brt_chat
#     if _brt_chat is None:
#     return _brt_chat

#     global _brt_embed
#     if _brt_embed is None:
#     return _brt_embed

#     global _ba_runtime
#     if _ba_runtime is None:
#     return _ba_runtime

#     """Return (system_core, brand, security) from the config.layers block."""
#     sys_core = (layers.get("system_core") or "").strip()
#     brand    = (layers.get("brand")       or "").strip()
#     security = (layers.get("security")    or "").strip()
#     return sys_core, brand, security


# # ==== Cell 10 ====
#     """
#     If user is a manager, keep only course snippets where sidecar.metadataAttributes.isManager == true.
#     Otherwise, return snippets unchanged (as per your requirement).
#     """
#     if not is_manager:
#         return snippets  # requirement: only enforce when user is a manager

#     kept, checked = [], 0
#     for s in snippets or []:
#         if not _is_course_snippet(s):
#             kept.append(s)
#             continue
#         meta = (s or {}).get("meta") or {}
#         uri  = meta.get("uri") or meta.get("source_uri") or ""
#         sidecar = read_course_sidecar(uri)
#         attrs = (sidecar.get("metadataAttributes") if isinstance(sidecar, dict) else {}) or {}
#         checked += 1
#         if attrs.get("isManager") is True:
#             kept.append(s)
#     # Optional: you can log how many course snippets were filtered for auditing
#     return kept


# # ==== Cell 12 ====

# @retry(wait=wait_exponential(multiplier=1, min=2, max=10),
#        stop=stop_after_attempt(3),

#     with conn.cursor() as cur:
#         cur.execute(sql, params)
#         return cur.fetchall()



# # ==== Cell 13 ====
#     if not x:
#         return {}
#     if isinstance(x, dict):
#         return x
#     try:
#         return _json.loads(x)
#     except Exception:
#         return {}

# @retry(wait=wait_exponential(multiplier=1, min=2, max=10),
#        stop=stop_after_attempt(3),

#     with conn.cursor() as cur:
#         cur.execute(sql, params)
#         return cur.fetchall()
