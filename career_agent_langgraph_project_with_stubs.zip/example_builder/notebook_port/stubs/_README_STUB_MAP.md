
# Notebook → Logical Stub Map (Non-intrusive)

**Source of truth:** `example_builder/notebook_port/exported_from_notebook.py`

These stubs are **organizational placeholders**. They import everything from the
source-of-truth module so importing them will not break current behavior.
Each stub includes a commented excerpt of lines heuristically related to that area.

When you're ready to refactor:
1. Move the uncommented relevant definitions from `exported_from_notebook.py` into the matching stub file.
2. Replace `from ...exported_from_notebook import *` with explicit imports as you migrate.
3. Run tests after each move to ensure parity.
