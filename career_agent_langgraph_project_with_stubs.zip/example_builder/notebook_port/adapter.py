
import runpy, os, sys, types, importlib, pathlib
def run_exported_notebook_as_module(env_overrides: dict | None = None):
    if env_overrides:
        for k, v in env_overrides.items():
            if v is not None:
                os.environ[k] = str(v)
    mod_name = "example_builder.notebook_port.exported_runtime"
    mod = types.ModuleType(mod_name)
    mod.__dict__["__name__"] = mod_name
    src_path = pathlib.Path(__file__).with_name("exported_from_notebook.py")
    source = src_path.read_text(encoding="utf-8")
    compiled = compile(source, str(src_path), "exec")
    exec(compiled, mod.__dict__, mod.__dict__)
    return mod
