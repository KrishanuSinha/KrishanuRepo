
import os
from dataclasses import dataclass
@dataclass(frozen=True)
class Env:
    AWS_REGION: str = os.getenv("AWS_REGION", "us-west-2")
    AWS_REGION_CHAT: str = os.getenv("AWS_REGION_CHAT", os.getenv("AWS_REGION","us-west-2"))
    AWS_REGION_EMBEDDINGS: str = os.getenv("AWS_REGION_EMBEDDINGS", os.getenv("AWS_REGION","us-west-2"))
    AWS_REGION_KB: str = os.getenv("AWS_REGION_KB", os.getenv("AWS_REGION","us-west-2"))
    PRIMARY_LLM_MODEL_NAME: str = os.getenv("PRIMARY_LLM_MODEL_NAME", "anthropic.claude-3-7-sonnet-20250219-v1:0")
    FAST_STREAM_MODEL_ID: str = os.getenv("FAST_STREAM_MODEL_ID", os.getenv("PRIMARY_LLM_MODEL_NAME", "anthropic.claude-3-7-sonnet-20250219-v1:0"))
    BEDROCK_EMBEDDING_MODEL: str = os.getenv("BEDROCK_EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0")
    CHAT_MODEL_RAW: str = os.getenv("CHAT_MODEL_RAW", "us.anthropic.claude-sonnet-4-20250514-v1:0")
    JOB_KB_ID: str = os.getenv("JOB_KB_ID", "")
    COURSES_KB_ID: str = os.getenv("COURSES_KB_ID", "")
    FIRST_TOKEN_BUDGET_SECS: float = float(os.getenv("FIRST_TOKEN_BUDGET_SECS", "5"))
    PROFILE_BUDGET_SECS: float = float(os.getenv("PROFILE_BUDGET_SECS", "0.25"))
    MENTOR_BUDGET_SECS: float = float(os.getenv("MENTOR_BUDGET_SECS", "0.4"))
