
import json, uuid
def gen_run_id() -> str: import uuid as _u; return str(_u.uuid4())
def j(obj): return json.dumps(obj, ensure_ascii=False, indent=2)
