
from typing import Dict, Any, List, DefaultDict
from collections import defaultdict
_chat_store: DefaultDict[str, List[Dict[str, Any]]] = defaultdict(list)
def append_chat(thread_id: str, role: str, content: str): _chat_store[thread_id].append({"role": role, "content": content})
def get_chat(thread_id: str) -> List[Dict[str, str]]: return _chat_store[thread_id]
