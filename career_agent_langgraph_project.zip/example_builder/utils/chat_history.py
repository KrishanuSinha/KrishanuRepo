
from typing import List, Dict
from .memory import append_chat, get_chat
def record_user_message(thread_id: str, content: str): append_chat(thread_id, "user", content)
def record_assistant_message(thread_id: str, content: str): append_chat(thread_id, "assistant", content)
def fetch_thread(thread_id: str) -> List[Dict[str, str]]: return get_chat(thread_id)
