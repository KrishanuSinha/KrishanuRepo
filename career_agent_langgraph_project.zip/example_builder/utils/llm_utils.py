
import os, json, time
from typing import Dict, Any, Generator, List
import boto3
from botocore.config import Config

def _bedrock_client(region: str):
    return boto3.client("bedrock-runtime", region_name=region, config=Config(retries={'max_attempts': 3}))

def _anthropic_messages_payload(model: str, system: str, user: str) -> Dict[str, Any]:
    return {
        "modelId": model,
        "messages": [{"role": "user", "content": [{"type": "text", "text": f"{system}\n\n{user}"}]}],
        "inferenceConfig": {"maxTokens": 1024, "temperature": 0.2},
    }

def call_bedrock_messages(model: str, system: str, user: str, region: str) -> Dict[str, Any]:
    cli = _bedrock_client(region)
    payload = _anthropic_messages_payload(model, system, user)
    resp = cli.invoke_model(modelId=model, body=json.dumps(payload))
    body = json.loads(resp["body"].read().decode("utf-8"))
    text = ""
    if "output" in body and "message" in body["output"]:
        parts = body["output"]["message"].get("content", [])
        for p in parts:
            if p.get("type") == "text":
                text += p.get("text", "")
    elif "content" in body:
        text = body["content"][0].get("text","")
    return {"text": text, "raw": body}

def stream_first_tokens_fast(model: str, system: str, user: str, region: str, first_token_budget_secs: float) -> Generator[str, None, None]:
    start = time.time()
    teaser = call_bedrock_messages(model, system, f"Return a single concise sentence preview for: {user}", region)["text"]
    for ch in teaser:
        yield ch
        if time.time() - start > first_token_budget_secs:
            break

def embed_texts_bedrock(model: str, region: str, texts: List[str]) -> List[List[float]]:
    cli = _bedrock_client(region)
    payload = {"inputText": texts[0] if len(texts)==1 else None, "texts": texts}
    resp = cli.invoke_model(modelId=model, body=json.dumps(payload))
    body = json.loads(resp["body"].read().decode("utf-8"))
    if "embeddings" in body:
        return [e["embedding"] for e in body["embeddings"]]
    if "embedding" in body:
        return [body["embedding"]]
    return []
