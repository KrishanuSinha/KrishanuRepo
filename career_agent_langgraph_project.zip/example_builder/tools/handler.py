
from __future__ import annotations
from typing import Dict, Any, List
import boto3
from botocore.config import Config

def _kb_runtime(region: str):
    return boto3.client("bedrock-agent-runtime", region_name=region, config=Config(retries={'max_attempts': 3}))

def retrieve_from_kb(kb_id: str, query: str, region: str, top_k: int = 5) -> List[Dict[str, Any]]:
    if not kb_id: return []
    cli = _kb_runtime(region)
    resp = cli.retrieve(
        knowledgeBaseId=kb_id,
        retrievalQuery={"text": query},
        retrievalConfiguration={ "vectorSearchConfiguration": {"numberOfResults": top_k} },
    )
    out = []
    for r in resp.get("retrievalResults", []):
        meta = r.get("metadata", {})
        src = meta.get("source", "kb")
        text = r.get("content", {}).get("text", "")
        out.append({"source": src, "text": text, "score": r.get("score", 0.0)})
    return out
