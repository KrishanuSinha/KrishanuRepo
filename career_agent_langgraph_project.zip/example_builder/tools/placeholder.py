
def noop_tool(*args, **kwargs): return {"ok": True, "note": "placeholder"}
