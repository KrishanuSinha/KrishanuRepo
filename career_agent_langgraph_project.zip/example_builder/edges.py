
def router_after_intent(state):
    intents = state.get("intents", [])
    if "job" in intents and "courses" in intents: return "jobs_then_courses"
    if "job" in intents: return "jobs_only"
    if "courses" in intents: return "courses_only"
    return "courses_only"
