
from typing import Any, Dict, List, TypedDict
class AppState(TypedDict, total=False):
    run_id: str
    email: str
    query: str
    intents: List[str]
    is_manager: bool | None
    job_snippets: List[Dict[str, Any]]
    course_snippets: List[Dict[str, Any]]
    draft_stream_chunks: List[str]
    final_answer: str
    citations: List[Dict[str, str]]
