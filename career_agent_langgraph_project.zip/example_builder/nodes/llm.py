
import json
from typing import Dict, Any
from ..utils.common import Env
from ..utils.llm_utils import call_bedrock_messages
from ..prompts.chat import INTENT_SYSTEM, INTENT_USER_TEMPLATE, FUSION_SYSTEM, FUSION_USER_TEMPLATE

def intent_node(state: Dict[str, Any]) -> Dict[str, Any]:
    env = Env()
    user = INTENT_USER_TEMPLATE.format(query=state["query"])
    res = call_bedrock_messages(env.PRIMARY_LLM_MODEL_NAME, INTENT_SYSTEM, user, env.AWS_REGION_CHAT)
    try:
        payload = json.loads(res["text"])
    except Exception:
        payload = {"intents": ["courses"], "is_manager": None, "reasoning": "fallback parse"}
    state["intents"] = payload.get("intents", [])
    state["is_manager"] = payload.get("is_manager", None)
    return state

def fusion_node(state: Dict[str, Any]) -> Dict[str, Any]:
    env = Env()
    jobs = "\n".join([f"[J{i+1}] {s['text']}" for i, s in enumerate(state.get("job_snippets", []))])
    courses = "\n".join([f"[C{i+1}] {s['text']}" for i, s in enumerate(state.get("course_snippets", []))])
    user = FUSION_USER_TEMPLATE.format(query=state["query"], email=state["email"], jobs=jobs or "(none)", courses=courses or "(none)")
    res = call_bedrock_messages(env.PRIMARY_LLM_MODEL_NAME, FUSION_SYSTEM, user, env.AWS_REGION_CHAT)
    state["final_answer"] = res["text"]
    citations = []
    for i,_ in enumerate(state.get("job_snippets", [])): citations.append({"kb":"jobs","source":f"J{i+1}"})
    for i,_ in enumerate(state.get("course_snippets", [])): citations.append({"kb":"courses","source":f"C{i+1}"})
    state["citations"] = citations
    return state
