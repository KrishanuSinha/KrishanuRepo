
from typing import Dict, Any
from ..utils.common import Env
from ..tools.handler import retrieve_from_kb
def jobs_tool_node(state: Dict[str, Any]) -> Dict[str, Any]:
    env = Env()
    state["job_snippets"] = retrieve_from_kb(env.JOB_KB_ID, state["query"], env.AWS_REGION_KB, top_k=5); return state
def courses_tool_node(state: Dict[str, Any]) -> Dict[str, Any]:
    env = Env()
    state["course_snippets"] = retrieve_from_kb(env.COURSES_KB_ID, state["query"], env.AWS_REGION_KB, top_k=5); return state
