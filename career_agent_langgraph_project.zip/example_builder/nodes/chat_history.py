
from typing import Dict, Any
from ..utils.chat_history import record_user_message, record_assistant_message
def ingest_user_node(state: Dict[str, Any]) -> Dict[str, Any]: record_user_message(state["run_id"], state["query"]); return state
def save_answer_node(state: Dict[str, Any]) -> Dict[str, Any]: record_assistant_message(state["run_id"], state.get("final_answer","")); return state
