
from typing import Callable, Dict, Any, List, Tuple
from langgraph.graph import StateGraph, END
class GraphBuilder:
    def __init__(self, initial_state: Dict[str, Any] | None = None):
        self.sg = StateGraph(dict)
        self.nodes: List[Tuple[str, Callable]] = []
        self.initial_state = initial_state or {}
    def add_node(self, name: str, fn: Callable[[Dict[str, Any]], Dict[str, Any]]):
        self.sg.add_node(name, fn); self.nodes.append((name, fn))
    def add_edge(self, src: str, dst: str):
        self.sg.add_edge(src, dst)
    def add_conditional_edges(self, src: str, router, options: list[str]):
        self.sg.add_conditional_edges(src, router, options)
    def set_entry(self, name: str):
        self.sg.set_entry_point(name)
    def compile(self):
        self.sg.add_edge(self.nodes[-1][0], END); return self.sg.compile()
