
from langgraph.graph import StateGraph, END
from .state import AppState
from .nodes.llm import intent_node, fusion_node
from .nodes.tool import jobs_tool_node, courses_tool_node
from .nodes.chat_history import ingest_user_node, save_answer_node
from .edges import router_after_intent
from .utils.common import Env
from .utils.llm_utils import stream_first_tokens_fast

def build_graph():
    sg = StateGraph(AppState)
    sg.add_node("ingest_user", ingest_user_node)
    sg.add_node("intent", intent_node)
    sg.add_node("jobs_tool", jobs_tool_node)
    sg.add_node("courses_tool", courses_tool_node)
    sg.add_node("fusion", fusion_node)
    sg.add_node("save_answer", save_answer_node)
    sg.set_entry_point("ingest_user")
    sg.add_edge("ingest_user", "intent")
    sg.add_conditional_edges("intent", router_after_intent, ["jobs_then_courses","jobs_only","courses_only"])
    sg.add_edge("jobs_tool", "courses_tool")
    sg.add_edge("courses_tool", "fusion")
    sg.add_edge("fusion", "save_answer")
    sg.add_edge("save_answer", END)
    sg.add_edge("intent", "jobs_tool", condition="jobs_then_courses")
    sg.add_edge("intent", "jobs_tool", condition="jobs_only")
    sg.add_edge("intent", "courses_tool", condition="courses_only")
    return sg

def stream_runner(state):
    env = Env()
    graph = build_graph().compile()
    for ch in stream_first_tokens_fast(env.FAST_STREAM_MODEL_ID,
                                       system="Return a single-sentence preview of the final answer.",
                                       user=state.get("query",""),
                                       region=env.AWS_REGION_CHAT,
                                       first_token_budget_secs=env.FIRST_TOKEN_BUDGET_SECS):
        yield {"type":"preview", "delta": ch}
    out = graph.invoke(state)
    final = out.get("final_answer","")
    for token in final.split(" "):
        yield {"type":"final", "delta": token + " "}
    return out
