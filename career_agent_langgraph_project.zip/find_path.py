
import argparse, sys
from example_builder import stream_runner
from example_builder.utils.utils import gen_run_id

def run_demo(query: str, email: str):
    st = {"run_id": gen_run_id(), "email": email, "query": query}
    print(f"---\nrun_id: {st['run_id']}\nemail: {email}\n---\n")
    print("## Preamble\n• Plan: retrieve relevant internal sources and fuse into an answer.\n• Ground guidance in your question and internal sources.\n• Cite sources as [J#]/[C#] and include a Sources list.\n")
    print("\n## Streaming Output\n")
    for ev in stream_runner(st):
        t = ev.get("type")
        if t in ("preview","final"):
            sys.stdout.write(ev["delta"]); sys.stdout.flush()
    print("\n\nDone.")

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--query", required=True)
    p.add_argument("--email", required=True)
    a = p.parse_args()
    run_demo(a.query, a.email)
