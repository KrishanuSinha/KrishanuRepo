
# Career Agent — LangGraph (AWS Bedrock + KB)

See usage instructions at the end.
