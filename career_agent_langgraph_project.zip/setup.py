
from setuptools import setup, find_packages
setup(
    name="career-agent-langgraph",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "langgraph>=0.2.30",
        "pydantic>=2.7.0",
        "python-dotenv>=1.0.1",
        "boto3>=1.34.0",
        "psycopg2-binary>=2.9.9",
        "tenacity>=8.2.3",
        "tqdm>=4.66.4",
        "orjson>=3.10.7",
    ],
    python_requires=">=3.11",
)
